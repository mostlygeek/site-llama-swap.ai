<script lang="ts">
  import { params } from "svelte-spa-router";
  import { models } from "../stores/api";
  import { loadingMessage, loadingPercent, statusDotColor } from "../stores/modelLoad";
  import type { Model } from "../lib/types";
  import ModelLoadButton from "../components/ModelLoadButton.svelte";
  import CopyableId from "../components/CopyableId.svelte";
  import * as Card from "$lib/components/ui/card/index.js";
  import { Tabs, TabsList, TabsTrigger, TabsContent } from "$lib/components/ui/tabs/index.js";
  import { ExternalLink } from "@lucide/svelte";
  import ModelActivityTab from "../components/model/ModelActivityTab.svelte";
  import ModelLogsTab from "../components/model/ModelLogsTab.svelte";
  import ModelDetailsTab from "../components/model/ModelDetailsTab.svelte";
  import { modelServerPath } from "../lib/modelUtils";
  import { formatAbsoluteTime, formatUptime } from "../lib/format";

  let modelId = $derived($params?.id ?? "");

  // Resolve the route param to a model record by ID, falling back to an
  // alias match so links to alias targets (e.g. selector targets) resolve.
  let model = $derived<Model | undefined>(
    $models.find((m) => m.id === modelId) ??
      $models.find((m) => m.aliases?.includes(modelId)),
  );
  let resolvedId = $derived(model?.id ?? modelId);
  // Only show a separate name when it differs from the ID, so the ID isn't
  // displayed twice.
  let hasName = $derived(!!model?.name && model.name !== model.id);

  // Uptime ticks once a second while the model is ready. It counts from
  // readyAt, which is on this browser's clock, so it works even when the
  // server's clock differs; readySince is only shown in the tooltip.
  let readySince = $derived(model?.readySince);
  let readyAt = $derived(model?.readyAt);
  let isReady = $derived(readyAt !== undefined);
  let now = $state(Date.now());
  // Re-runs when a status update moves readyAt, so `now` is never older
  // than readyAt's anchor.
  $effect(() => {
    if (readyAt === undefined) return;
    now = Date.now();
    const timer = setInterval(() => (now = Date.now()), 1000);
    return () => clearInterval(timer);
  });
  let uptime = $derived(readyAt !== undefined ? formatUptime(now - readyAt) : "");

  // Loading progress the upstream reports through its health check while starting.
  let percent = $derived(loadingPercent(model));
  let message = $derived(loadingMessage(model));
</script>

<div class="flex h-full flex-col gap-3 overflow-y-auto p-0 sm:gap-4 sm:p-2">
  {#if !model}
    <Card.Root class="shrink-0 p-6">
      <p class="text-muted-foreground">Model “{modelId}” not found.</p>
      <a href="/" class="text-primary hover:underline">Back to Playground</a>
    </Card.Root>
  {:else}
    <Card.Root class="shrink-0 gap-0 overflow-hidden py-0">
      <Card.Header class="shrink-0 gap-2 px-4 py-3">
        <div class="flex items-start gap-2">
          <div class="flex min-w-0 flex-1 flex-col gap-1">
            {#if hasName}
              <Card.Title class="text-lg break-words">{model.name}</Card.Title>
            {:else}
              <Card.Title class="-ml-1 text-lg">
                <CopyableId value={model.id} />
              </Card.Title>
            {/if}
            <div class="text-muted-foreground flex flex-wrap items-center gap-x-2 gap-y-1 text-sm">
              {#if hasName}
                <CopyableId value={model.id} class="-ml-1 font-mono text-xs" />
              {/if}
              <span class="text-xs uppercase tracking-wide">{model.state}</span>
              {#if percent !== undefined}
                <span class="text-xs tabular-nums">{percent}%</span>
              {/if}
              {#if isReady}
                <span class="text-xs" title={readySince ? `Ready since ${formatAbsoluteTime(readySince)}` : undefined}>
                  up {uptime}
                </span>
              {/if}
            </div>
          </div>
          <div class="flex shrink-0 items-center gap-2">
            {#if !model.peerID}
              <a
                href={modelServerPath(resolvedId)}
                target="_blank"
                rel="noopener noreferrer"
                class="text-muted-foreground hover:text-foreground"
                title="Open model server"
                aria-label="Open model server"
              >
                <ExternalLink class="size-4" />
              </a>
              <ModelLoadButton {model} size="sm" />
            {/if}
          </div>
        </div>
        {#if model.description}
          <p class="text-muted-foreground text-sm"><em>{model.description}</em></p>
        {/if}
        {#if message}
          <p class="text-muted-foreground text-xs break-words">{message}</p>
        {/if}
        {#if model.aliases && model.aliases.length > 0}
          <div class="text-muted-foreground flex flex-wrap items-center gap-x-1 gap-y-1 text-xs">
            <span>Aliases:</span>
            {#each model.aliases as alias (alias)}
              <CopyableId value={alias} class="font-mono" />
            {/each}
          </div>
        {/if}
      </Card.Header>
      <!-- Load status bar; the state text in the header carries it for screen readers. -->
      {#if percent !== undefined}
        <!-- The upstream reports progress, so fill the bar to it instead of pulsing. -->
        <div aria-hidden="true" class="bg-muted h-1 w-full shrink-0">
          <div class="bg-warning h-full transition-[width] duration-500" style:width="{percent}%"></div>
        </div>
      {:else}
        <div
          aria-hidden="true"
          class={`h-1 w-full shrink-0 transition-colors ${statusDotColor(model)}`}
          class:animate-pulse={model.state === "starting" || model.state === "stopping"}
        ></div>
      {/if}
    </Card.Root>

    <Tabs value="activity" class="min-h-[min(20rem,70vh)] flex-1">
      <TabsList variant="line">
        <TabsTrigger value="activity">Activity</TabsTrigger>
        <TabsTrigger value="logs">Logs</TabsTrigger>
        <TabsTrigger value="details">Details</TabsTrigger>
      </TabsList>

      <!-- Activity -->
      <TabsContent value="activity">
        <ModelActivityTab modelId={resolvedId} />
      </TabsContent>

      <!-- Logs -->
      <TabsContent value="logs" class="min-h-0 flex-1">
        <ModelLogsTab modelId={resolvedId} />
      </TabsContent>

      <!-- Details -->
      <TabsContent value="details">
        <ModelDetailsTab model={model} />
      </TabsContent>
    </Tabs>
  {/if}
</div>
